<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Offers Management</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="main-header">
        <div class="container">
            <nav class="navbar">
                <a href="<?php echo BASE_URL; ?>" class="logo">Hotel<span>Offers</span></a>
                <ul class="nav-links">
                    <?php if (isLoggedIn()): ?>
                        <li><a href="<?php echo BASE_URL; ?>/offers">My Offers</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/offers/create.php">Add Offer</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/auth/logout.php">Logout</a></li>
                    <?php else: ?>
                        <li><a href="<?php echo BASE_URL; ?>/auth/login.php">Login</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/auth/register.php">Register</a></li>
                    <?php endif; ?>
                </ul>
                <div class="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </nav>
        </div>
    </header>
    <main class="container">
