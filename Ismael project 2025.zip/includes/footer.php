    </main>
    <footer class="main-footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> Hotel Offers Management System. All rights reserved.</p>
        </div>
    </footer>
    <script src="<?php echo BASE_URL; ?>/assets/js/script.js"></script>
</body>
</html>
