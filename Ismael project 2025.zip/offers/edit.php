
```php
<?php
require_once '../../includes/config.php';
require_once '../../includes/auth_functions.php';

redirectIfNotLoggedIn();

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$offer_id = $_GET['id'];
$errors = [];

// Get the current offer
try {
    $stmt = $pdo->prepare("SELECT * FROM hotel_offers WHERE id = ? AND user_id = ?");
    $stmt->execute([$offer_id, $_SESSION['user_id']]);
    $offer = $stmt->fetch();
    
    if (!$offer) {
        header("Location: index.php");
        exit();
    }
} catch (PDOException $e) {
    die("Error fetching offer: " . $e->getMessage());
}

$title = $offer['title'];
$description = $offer['description'];
$price = $offer['price'];
$location = $offer['location'];
$amenities = $offer['amenities'];
$current_image = $offer['image_path'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitizeInput($_POST['title']);
    $description = sanitizeInput($_POST['description']);
    $price = sanitizeInput($_POST['price']);
    $location = sanitizeInput($_POST['location']);
    $amenities = sanitizeInput($_POST['amenities']);
    
    // Validate inputs
    if (empty($title)) {
        $errors['title'] = 'Title is required';
    }
    
    if (empty($description)) {
$errors['description'] = 'Description is required';
    }
    
    if (empty($price)) {
        $errors['price'] = 'Price is required';
    } elseif (!is_numeric($price) || $price <= 0) {
        $errors['price'] = 'Price must be a positive number';
    }
    
    if (empty($location)) {
        $errors['location'] = 'Location is required';
    }
    
    // Handle file upload if a new image is provided
    $image_path = $current_image;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../../assets/images/offers/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $file_name = time() . '_' . basename($_FILES['image']['name']);
        $target_path = $upload_dir . $file_name;
        
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $file_type = $_FILES['image']['type'];
        
        if (in_array($file_type, $allowed_types)) {
            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
                // Delete old image if it exists
                if (!empty($current_image) && file_exists('../../' . $current_image)) {
                    unlink('../../' . $current_image);
                }
                $image_path = 'assets/images/offers/' . $file_name;
            } else {
                $errors['image'] = 'Failed to upload image';
            }
        } else {
            $errors['image'] = 'Only JPG, PNG, and GIF files are allowed';
        }
    }
    
    // Update offer if no errors
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("UPDATE hotel_offers SET title = ?, description = ?, price = ?, location = ?, amenities = ?, image_path = ?, updated_at = NOW() WHERE id = ? AND user_id = ?");
            $stmt->execute([
                $title,
                $description,
                $price,
                $location,
                $amenities,
                $image_path,
                $offer_id,
                $_SESSION['user_id']
            ]);
            
            $_SESSION['success_message'] = 'Offer updated successfully!';
            header("Location: index.php");
            exit();
        } catch (PDOException $e) {
            $errors['general'] = 'Failed to update offer: ' . $e->getMessage();
        }
    }
}
?>

<?php include '../../includes/header.php'; ?>

<h1>Edit Offer</h1>

<?php if (!empty($errors['general'])): ?>
    <div class="alert alert-danger"><?php echo $errors['general']; ?></div>
<?php endif; ?>

<form method="POST" action="" enctype="multipart/form-data">
    <div class="form-group">
        <label for="title" class="form-label">Title</label>
        <input type="text" id="title" name="title" class="form-control" 
               value="<?php echo htmlspecialchars($title); ?>" required>
        <?php if (!empty($errors['title'])): ?>
            <small class="text-danger"><?php echo $errors['title'];