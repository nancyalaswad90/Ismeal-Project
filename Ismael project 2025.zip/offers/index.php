<?php
require_once '../../includes/config.php';
require_once '../../includes/auth_functions.php';

redirectIfNotLoggedIn();

// Get all offers for the current user
try {
    $stmt = $pdo->prepare("SELECT * FROM hotel_offers WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([$_SESSION['user_id']]);
    $offers = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Error fetching offers: " . $e->getMessage());
}

$success_message = '';
if (isset($_SESSION['success_message'])) {
    $success_message = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}
?>

<?php include '../../includes/header.php'; ?>

<h1>My Hotel Offers</h1>

<?php if (!empty($success_message)): ?>
    <div class="alert alert-success"><?php echo $success_message; ?></div>
<?php endif; ?>

<a href="create.php" class="btn btn-secondary mb-3">Add New Offer</a>

<?php if (empty($offers)): ?>
    <p>No offers found. Create your first offer!</p>
<?php else: ?>
    <div class="grid">
        <?php foreach ($offers as $offer): ?>
            <div class="card">
                <?php if (!empty($offer['image_path'])): ?>
                    <img src="<?php echo BASE_URL . '/' . $offer['image_path']; ?>" alt="<?php echo htmlspecialchars($offer['title']); ?>" class="card-img">
                    <?php else: ?>
                    <img src="<?php echo BASE_URL; ?>/assets/images/default-hotel.jpg" alt="Default hotel image" class="card-img">
                <?php endif; ?>
                
                <div class="card-body">
                    <h3 class="card-title"><?php echo htmlspecialchars($offer['title']); ?></h3>
                    <p class="card-text"><?php echo htmlspecialchars(substr($offer['description'], 0, 100)); ?>...</p>
                    <div class="card-location">
                        <i class="fas fa-map-marker-alt"></i>
                        <?php echo htmlspecialchars($offer['location']); ?>
                    </div>
                    <div class="card-price">$<?php echo number_format($offer['price'], 2); ?></div>
                    
                    <div class="d-flex justify-content-between">
                        <a href="edit.php?id=<?php echo $offer['id']; ?>" class="btn btn-warning">Edit</a>
                        <a href="delete.php?id=<?php echo $offer['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this offer?')">Delete</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php include '../../includes/footer.php'; ?>
